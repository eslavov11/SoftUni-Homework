﻿namespace Cosmetics.Products
{
    public class DoNotDeleteMe
    {
        // Put all your classes in this namespace and delete this class...
    }
}
