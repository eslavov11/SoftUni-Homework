﻿namespace Empires.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
