﻿namespace Empires.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
