﻿namespace Empires.Interfaces
{
    public interface IUserInterface : IReader, IWriter
    {
    }
}
