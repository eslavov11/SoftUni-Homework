﻿namespace Empires.Models.Resources
{
    public enum ResourceType
    {
        Gold,
        Steel
    }
}
