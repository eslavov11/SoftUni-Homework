﻿namespace Blops.Exceptions
{
    public class AttackBlopException : BlopException
    {
        public AttackBlopException(string msg)
            : base(msg)
        {
        }
    }
}
