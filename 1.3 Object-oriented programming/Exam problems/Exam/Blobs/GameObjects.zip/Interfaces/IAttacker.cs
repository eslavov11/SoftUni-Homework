﻿namespace Blops.Interfaces
{
    public interface IAttacker
    {
        int Damage { get; set; }

        int InitialDamage { get; }
    }
}
