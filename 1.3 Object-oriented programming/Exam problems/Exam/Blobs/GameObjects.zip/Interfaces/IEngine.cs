﻿namespace Blops.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
