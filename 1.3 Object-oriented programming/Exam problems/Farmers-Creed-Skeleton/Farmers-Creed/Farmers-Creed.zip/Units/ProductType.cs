﻿namespace FarmersCreed.Units
{
    public enum ProductType
    {
        Grain,
        Tobacco,
        PorkMeat,
        Cherry,
        Milk
    }
}
