﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infestation.Supplements
{
    public class AggressionCatalyst : Catalyst
    {
        public AggressionCatalyst()
        {
            base.AggressionEffect = 3;
        }
    }
}
