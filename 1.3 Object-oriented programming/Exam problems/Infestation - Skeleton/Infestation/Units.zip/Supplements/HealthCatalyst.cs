﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infestation.Supplements
{
    public class HealthCatalyst : Catalyst
    {
        public HealthCatalyst()
        {
            base.HealthEffect = 3;
        }
    }
}
