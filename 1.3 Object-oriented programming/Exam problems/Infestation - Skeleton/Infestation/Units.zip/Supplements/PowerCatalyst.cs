﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infestation.Supplements
{
    public class PowerCatalyst : Catalyst
    {
        public PowerCatalyst()
        {
            base.PowerEffect = 3;
        }
    }
}
