﻿namespace _02.Animals.Interfaces
{
    interface ISoundProducible
    {
        void ProduceSound();
    }
}
