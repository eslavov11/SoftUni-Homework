﻿namespace _03.CompanyHierarchy.People
{
    public enum Department
    {
        Production,
        Accounting,
        Sales,
        Marketing
    }
}
