﻿namespace _03.CompanyHierarchy.People
{
    public enum State
    {
        Open,
        Close
    }
}
