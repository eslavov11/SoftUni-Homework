﻿namespace BangaloreUniversityLearningSystem
{
    using BangaloreUniversityLearningSystem.Core;

    public class BangaloreUniversityMain
    {
        public static void Main()
        {
            var engine = new BangaloreUniversityEngine();
            engine.Run();
        }
    }
}