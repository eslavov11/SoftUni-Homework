﻿namespace BangaloreUniversityLearningSystem.Enums
{
    public enum Role
    {
        Student,
        Lecturer
    }
}