﻿namespace BangaloreUniversityLearningSystem.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}