﻿namespace BangaloreUniversityLearningSystem.Utilities
{
    public static class Constants
    {
    }
}
