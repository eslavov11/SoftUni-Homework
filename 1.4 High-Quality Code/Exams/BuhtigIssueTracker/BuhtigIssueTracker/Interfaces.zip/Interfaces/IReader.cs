﻿namespace BuhtigIssueTracker.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
