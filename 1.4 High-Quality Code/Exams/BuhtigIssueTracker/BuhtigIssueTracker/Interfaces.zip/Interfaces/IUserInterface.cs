﻿namespace BuhtigIssueTracker.Interfaces
{
    public interface IUserInterface : IReader, IWriter
    {
    }
}
