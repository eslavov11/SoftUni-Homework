﻿namespace BuhtigIssueTracker.Utility
{
    public static class Constants
    {
    }
}
