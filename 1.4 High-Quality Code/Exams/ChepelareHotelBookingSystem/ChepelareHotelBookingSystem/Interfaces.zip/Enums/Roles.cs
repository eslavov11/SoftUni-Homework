﻿namespace ChepelareHotelBookingSystem.Enums
{
    public enum Roles
    {
        User,
        VenueAdmin
    }
}
