﻿namespace ChepelareHotelBookingSystem.Interfaces
{
    public interface IDbEntity
    {
        int Id { get; set; }
    }
}