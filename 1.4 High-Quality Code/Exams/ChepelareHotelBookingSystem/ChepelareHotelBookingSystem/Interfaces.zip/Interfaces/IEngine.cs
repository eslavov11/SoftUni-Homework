namespace ChepelareHotelBookingSystem.Interfaces
{
    public interface IEngine
    {
        void StartOperation();
    }
}