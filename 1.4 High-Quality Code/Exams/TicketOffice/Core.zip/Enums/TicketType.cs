namespace TicketOffice.Enums
{
    public enum TicketType
    {
        Bus,
        Flight,
        Train
    }
}