namespace TravelAgency.Data
{
    using System;
    using System.Collections.Generic;
    using Enums;
    using Interfaces;
    using Models.Tickets;
    using Wintellect.PowerCollections;

    public class TicketCatalog : ITicketCatalog
    {
        private readonly Dictionary<string, Ticket> dict;
        private readonly MultiDictionary<string, Ticket> dict2;
        private readonly OrderedMultiDictionary<DateTime, Ticket> dict3;
        private int airTicketsCount;
        private int busTicketsCount;
        private int trainTicketsCount;

        public TicketCatalog()
        {
            this.dict = new Dictionary<string, Ticket>();
            this.dict2 = new MultiDictionary<string, Ticket>(true);
            this.dict3 = new OrderedMultiDictionary<DateTime, Ticket>(true);
        }

        public static string ReadTickets(ICollection<Ticket> tickets)
        {
            List<Ticket> sortedTickets = new List<Ticket>(tickets);

            sortedTickets.Sort();
            string result = string.Empty;

            // PERFORMANCE: Unnecessary loop
            return string.Join(", ", sortedTickets);
        }

        public int GetTicketsCount(string type)
        {
            var typeName = type[0].ToString().ToUpper() + type.Substring(1, type.Length);
            TicketType ticketType = (TicketType)Enum.Parse(typeof(TicketType), typeName);

            switch (ticketType)
            {
                case TicketType.Air:
                    return this.airTicketsCount;
                case TicketType.Bus:
                    return this.busTicketsCount;
                case TicketType.Train:
                    return this.trainTicketsCount;
                default:
                    return default(int);
            }
        }

        public string AddTicket(Ticket ticket)
        {
            string key = ticket.Key;
            if (this.dict.ContainsKey(key))
            {
                return "Duplicate ticket";
            }

            this.dict.Add(key, ticket);
            string fromToKey = ticket.FromToKey;
            this.dict2.Add(fromToKey, ticket);
            this.dict3.Add(ticket.DateAndTime, ticket);

            return "Ticket added";
        }

        public string DeleteTicket(Ticket ticket)
        {
            string key = ticket.Key;
            if (!this.dict.ContainsKey(key))
            {
                return "Ticket does not exist";
            }

            ticket = this.dict[key];
            this.dict.Remove(key);
            string fromToKey = ticket.FromToKey;
            this.dict2.Remove(fromToKey, ticket);
            this.dict3.Remove(ticket.DateAndTime, ticket);

            return "Ticket deleted";
        }

        public string AddAirTicket(
            string flightNumber,
            string from,
            string to,
            string airline,
            string dateTime,
            string price)
        {
            AirTicket ticket = new AirTicket(flightNumber, from, to, airline, dateTime, price);

            string result = this.AddTicket(ticket);
            if (result.Contains("added"))
            {
                this.airTicketsCount++;
            }

            return result;
        }

        public string DeleteAirTicket(string flightNumber)
        {
            AirTicket ticket = new AirTicket(flightNumber);

            string result = this.DeleteTicket(ticket);
            if (result.Contains("deleted"))
            {
                this.airTicketsCount--;
            }

            return result;
        }

        public string AddTrainTicket(string from, string to, string dateTime, string price, string studentPrice)
        {
            TrainTicket ticket = new TrainTicket(from, to, dateTime, price, studentPrice);

            string result = this.AddTicket(ticket);
            if (result.Contains("added"))
            {
                this.trainTicketsCount++;
            }

            return result;
        }

        public string DeleteTrainTicket(string from, string to, string dateTime)
        {
            TrainTicket ticket = new TrainTicket(from, to, dateTime);
            string result = this.DeleteTicket(ticket);

            if (result.Contains("deleted"))
            {
                this.trainTicketsCount--;
            }

            return result;
        }

        public string AddBusTicket(string from, string to, string travelCompany, string dateTime, string price)
        {
            BusTicket ticket = new BusTicket(from, to, travelCompany, dateTime, price);

            if (this.dict.ContainsKey(ticket.Key))
            {
                return "Duplicate ticket";
            }

            this.dict.Add(ticket.Key, ticket);
            string fromToKey = ticket.FromToKey;
            this.dict2.Add(fromToKey, ticket);
            this.dict3.Add(ticket.DateAndTime, ticket);
            this.busTicketsCount++;

            return "Ticket added";
        }

        public string DeleteBusTicket(string from, string to, string travelCompany, string dateTime)
        {
            BusTicket ticket = new BusTicket(from, to, travelCompany, dateTime);
            string result = this.DeleteTicket(ticket);

            if (result.Contains("deleted"))
            {
                this.busTicketsCount--;
            }

            return result;
        }

        public string FindTickets(string from, string to)
        {
            string fromToKey = Ticket.CreateFromToKey(from, to);
            if (!this.dict2.ContainsKey(fromToKey))
            {
                return "Not found";
            }

            List<Ticket> ticketsFound = new List<Ticket>();
            foreach (var t in this.dict2.Values)
            {
                if (t.FromToKey == fromToKey)
                {
                    ticketsFound.Add(t);
                }
            }

            string ticketsAsString = ReadTickets(ticketsFound);

            return ticketsAsString;
        }

        public string FindTicketsInInterval(DateTime startDateTime, DateTime endDateTime)
        {
            // Do not toch! It work!!! I spend 10 hours of fix buggy here
            var ticketsFound = this.dict3.Range(startDateTime, true, endDateTime, true).Values;
            if (ticketsFound.Count <= 0)
            {
                return "Not found";
            }

            string ticketsAsString = ReadTickets(ticketsFound);

            return ticketsAsString;
        }

        public string AddAirTicket(
            string flightNumber,
            string from,
            string to,
            string airline,
            DateTime dateTime,
            decimal price)
        {
            return this.AddAirTicket(flightNumber, from, to, airline, dateTime.ToString("dd.MM.yyyy HH:mm"), price.ToString());
        }

        string ITicketCatalog.DeleteAirTicket(string flightNumber)
        {
            return this.DeleteAirTicket(flightNumber);
        }

        public string AddTrainTicket(string from, string to, DateTime dateTime, decimal price, decimal studentPrice)
        {
            return this.AddTrainTicket(
                from,
                to,
                dateTime.ToString("dd.MM.yyyy HH:mm"),
                price.ToString(),
                studentPrice.ToString());
        }

        public string DeleteTrainTicket(string from, string to, DateTime dateTime)
        {
            return this.DeleteTrainTicket(from, to, dateTime.ToString("dd.MM.yyyy HH:mm"));
        }

        public string AddBusTicket(string from, string to, string travelCompany, DateTime dateTime, decimal price)
        {
            return this.AddBusTicket(
                from,
                to,
                travelCompany,
                dateTime.ToString("dd.MM.yyyy HH:mm"),
                price.ToString());
        }

        public string DeleteBusTicket(string from, string to, string travelCompany, DateTime dateTime)
        {
            return this.DeleteBusTicket(from, to, travelCompany, dateTime.ToString("dd.MM.yyyy HH:mm"));
        }

        public int GetTicketsCount(TicketType type)
        {
            switch (type)
            {
                case TicketType.Air:
                    return this.airTicketsCount;
                case TicketType.Bus:
                    return this.busTicketsCount;
                case TicketType.Train:
                    return this.trainTicketsCount;
                default:
                    return default(int);
            }
        }
    }
}