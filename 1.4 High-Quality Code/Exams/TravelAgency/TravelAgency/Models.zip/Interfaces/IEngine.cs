﻿namespace TravelAgency.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
