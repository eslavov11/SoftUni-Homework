﻿namespace TravelAgency.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
