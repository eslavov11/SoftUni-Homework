﻿namespace TravelAgency.Interfaces
{
    public interface IUserInterface : IReader, IWriter
    {
    }
}
