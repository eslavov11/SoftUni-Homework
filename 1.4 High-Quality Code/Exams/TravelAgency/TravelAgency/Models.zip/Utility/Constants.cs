﻿namespace TravelAgency.Utility
{
    public static class Constants
    {
    }
}
