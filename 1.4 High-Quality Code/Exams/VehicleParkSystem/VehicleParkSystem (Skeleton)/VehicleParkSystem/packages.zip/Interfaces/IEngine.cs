namespace VehicleParkSystem.Interfaces
{
    interface IEngine
    {
        void Run();
    }
}