﻿namespace Blops.Interfaces
{
    public interface IDestroyable
    {
        int Health { get; set; }

        int InitialHealth { get; }
    }
}
