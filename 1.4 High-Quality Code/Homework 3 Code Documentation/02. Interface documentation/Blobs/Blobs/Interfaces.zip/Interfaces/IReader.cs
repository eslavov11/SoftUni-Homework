﻿namespace Blops.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
