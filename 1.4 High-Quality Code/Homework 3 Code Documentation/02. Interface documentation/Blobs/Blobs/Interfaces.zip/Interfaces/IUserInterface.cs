﻿namespace Blops.Interfaces
{
    public interface IUserInterface : IReader, IWriter
    {
    }
}
