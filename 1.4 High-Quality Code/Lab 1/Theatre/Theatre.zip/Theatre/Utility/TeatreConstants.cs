﻿namespace Theatre.Utility
{
    public static class TeatreConstants
    {
    }
}
