﻿namespace RPG.Characters
{
    using Bridge.Weapons;
    using RPG.Characters;

    public class Warrior : Character
    {
        public Warrior(Weapon weapon)
            : base(weapon)
        {
        }
    }
}
