﻿namespace RPG.Weapons
{
    using Bridge.Weapons;

    public class Axe : Weapon
    {
    }
}
