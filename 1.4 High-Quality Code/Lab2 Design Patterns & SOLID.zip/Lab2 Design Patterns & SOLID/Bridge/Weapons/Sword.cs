﻿namespace RPG.Weapons
{
    using Bridge.Weapons;

    public class Sword : Weapon
    {
    }
}
