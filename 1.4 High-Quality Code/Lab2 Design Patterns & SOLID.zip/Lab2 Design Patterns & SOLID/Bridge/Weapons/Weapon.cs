﻿namespace Bridge.Weapons
{
    public abstract class Weapon
    {
    }
}
