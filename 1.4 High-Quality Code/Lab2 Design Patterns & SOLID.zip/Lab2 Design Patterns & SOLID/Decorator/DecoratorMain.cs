﻿namespace _9.Decorator
{
    public class DecoratorMain
    {
        private static void Main()
        {
        }
    }
}
