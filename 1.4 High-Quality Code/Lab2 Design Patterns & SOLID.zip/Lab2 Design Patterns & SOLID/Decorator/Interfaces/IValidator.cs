﻿namespace _9.Decorator.Interfaces
{
    public interface IValidator
    {
        bool Validate(string input);
    }
}