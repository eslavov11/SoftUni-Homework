﻿namespace Skyrim.Units
{
    public class Dragon : Unit
    {
        public Dragon(string name, int attackPoints, int healthPoints) 
            : base(name, attackPoints, healthPoints)
        {
        }
    }
}
