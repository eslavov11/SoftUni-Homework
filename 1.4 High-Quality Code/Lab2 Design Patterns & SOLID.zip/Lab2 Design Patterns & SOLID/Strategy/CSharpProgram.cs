﻿using System;

namespace Strategy
{
    public class Program
    {
        public static void Main()
        {
            Console.WriteLine("My name is Gosho and I crack Judge system.");
        }
    }
}
