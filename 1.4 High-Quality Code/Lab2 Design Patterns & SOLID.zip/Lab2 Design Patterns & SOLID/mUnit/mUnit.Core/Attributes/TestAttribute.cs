﻿namespace mUnit.Core.Attributes
{
    using System;

    [AttributeUsage(AttributeTargets.Method)]
    public class TestAttribute : Attribute
    {
    }
}
