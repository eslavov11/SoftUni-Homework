﻿namespace mUnit.Core.Attributes
{
    using System;

    [AttributeUsage(AttributeTargets.Class)]
    public class TestContainerAttribute : Attribute
    {
    }
}
