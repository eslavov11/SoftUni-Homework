﻿namespace mUnit.Core.Interfaces
{
    public interface IOutputWriter
    {
        void Write(string output);
    }
}
