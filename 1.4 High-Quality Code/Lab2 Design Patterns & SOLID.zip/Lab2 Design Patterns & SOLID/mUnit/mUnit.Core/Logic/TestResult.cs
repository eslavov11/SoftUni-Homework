﻿namespace mUnit.Core.Logic
{
    public enum TestResult
    {
        NotRun,
        Passed,
        Failed,
        Skipped
    }
}
