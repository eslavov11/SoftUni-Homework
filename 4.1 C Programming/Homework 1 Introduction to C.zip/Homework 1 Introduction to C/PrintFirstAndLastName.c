#include <stdio.h>
int main()
{
    printf("Edward\n");
    printf("Georgiev");
    return 0;
}
