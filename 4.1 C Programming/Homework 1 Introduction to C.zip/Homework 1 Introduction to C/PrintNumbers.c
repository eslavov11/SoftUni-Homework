#include <stdio.h>
int main()
{
    printf("1\n");
    printf("101\n");
    printf("1001");
    return 0;
}
