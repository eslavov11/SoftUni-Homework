#include <stdio.h>
int main()
{
    printf("My name is Edward.\n");
    return 0;
}
