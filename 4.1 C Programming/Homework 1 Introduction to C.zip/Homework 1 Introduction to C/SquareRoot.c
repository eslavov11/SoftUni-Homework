#include <stdio.h>
#include <math.h>
int main()
{
    double result = sqrt(12345);
    printf("%lf\n", result);
    return 0;
}
