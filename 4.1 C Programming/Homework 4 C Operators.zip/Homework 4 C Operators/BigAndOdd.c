#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv)
{
    int number, bigAndOdd;
    scanf("%d", &number);
    bigAndOdd = number%2 && number>20;
    printf("%d\n", bigAndOdd);
    return (EXIT_SUCCESS);
}

