#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main(int argc, char** argv)
{
    bool result;
    int number;
    scanf("%d", &number);
    result = (number%5 && number%7)^1;
    printf("%d\n", result);
    return (EXIT_SUCCESS);
}

