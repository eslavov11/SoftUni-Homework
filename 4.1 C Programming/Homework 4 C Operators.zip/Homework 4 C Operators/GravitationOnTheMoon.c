#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv)
{
    float weight;
    scanf("%f", &weight);
    printf("%f\n", (float)(weight*17.0/100) );
    return (EXIT_SUCCESS);
}
//The gravitational field of the Moon is approximately 17%
//of that on the Earth. Write a program that calculates the 
//weight of a man on the moon by a given weight on the Earth.
