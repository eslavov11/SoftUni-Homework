#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv)
{
    int oddOrEven, number;
    scanf("%d", &number);
    oddOrEven = number%2;
    printf("%d\n",oddOrEven);
    return (EXIT_SUCCESS);
}

