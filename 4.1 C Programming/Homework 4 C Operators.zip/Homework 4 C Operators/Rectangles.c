#include <stdio.h>
#include <stdlib.h>

int main() 
{
    float width, height, perimeter, area;
    scanf("%f", &width);
    scanf("%f", &height);
    printf("Perimeter: %.2f\nArea: %.2f\n", (width*2+height*2),(width*height));
    return 0;
}

